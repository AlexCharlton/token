#ifndef __OPENCV_OLD_CXMISC_H__
#define __OPENCV_OLD_CXMISC_H__

#ifdef __cplusplus
#  include "opencv2/core/utility.hpp"
#endif

#endif
